---
name: deploy
description: Deploy all Railway services for the שמאי בקליק agents system (dashboard + all 7 agents). Use when user writes /deploy or asks to deploy to Railway.
---

# Deploy — שמאי בקליק (Railway)

Run TypeScript check first, then deploy all 8 services sequentially.

**Project root:** `/Users/simplevaad/Downloads/Claude/agents/`

## Step 1 — TypeScript check (dashboard only)

```bash
cd /Users/simplevaad/Downloads/Claude/agents/dashboard && npx tsc -b
```

If there are TS errors — stop and fix them before continuing.

## Step 2 — Deploy all services

Run these commands sequentially (each `cd` uses absolute path):

```bash
cd /Users/simplevaad/Downloads/Claude/agents/dashboard && npx @railway/cli up --service 29e09e63-07c9-4152-9bf8-fce4f92adad9 --environment 1527c8e7-374f-460c-a0a1-387b33bdba3b -d

cd /Users/simplevaad/Downloads/Claude/agents/agent_01_case_opener && npx @railway/cli up --service 1785505c-0ff2-47b5-8864-0fda7c805938 --environment 6265e2d8-4269-4350-834c-6d608bd4079d -d

cd /Users/simplevaad/Downloads/Claude/agents/agent_02_case_router && npx @railway/cli up --service 69af2b24-b69c-4da9-a75a-4d54840c2116 --environment 75fc789c-6dea-4d1a-ab94-f6a95f326fe4 -d

cd /Users/simplevaad/Downloads/Claude/agents/agent_03_case_notifier && npx @railway/cli up --service 00b31275-d627-4f61-85d7-68c1bd1dfb53 --environment 55814a07-5477-4711-b940-2daafb5520e6 -d

cd /Users/simplevaad/Downloads/Claude/agents/agent_04_visit_tracker && npx @railway/cli up --service 447a3c5b-4604-4a54-8349-f32d20a44d11 --environment 9ef73722-decd-4632-bbce-987a3df8f21f -d

cd /Users/simplevaad/Downloads/Claude/agents/agent_05_document_collector && npx @railway/cli up --service c2b7f89b-e141-4e8d-87fd-d771c464fcd2 --environment 83ec743b-274f-4270-b8bc-9a7021ac6cf7 -d

cd /Users/simplevaad/Downloads/Claude/agents/agent_06_preliminary_notice && npx @railway/cli up --service 5214a6ae-a6c0-46ed-a403-e9576192a6d2 --environment 6d95fb7f-efe0-40e2-ac4b-225f970008b1 -d

cd /Users/simplevaad/Downloads/Claude/agents/agent_07_expert_opinion && npx @railway/cli up --service 168840b4-84a1-4d09-8e5c-3ae36ca51e0b --environment 652be2e9-1971-4c99-95a6-5dcf72832b6f -d
```

## Step 3 — Confirm

After all commands complete successfully, report to the user:
"דפלוי הושלם — dashboard + 7 סוכנים נשלחו ל-Railway."
