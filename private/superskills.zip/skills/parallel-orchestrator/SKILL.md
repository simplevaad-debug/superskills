---
name: parallel-orchestrator
description: "Auto-decompose complex tasks into parallel subagent teams. Activates automatically when detecting multi-step tasks, system work, multi-file changes, integrations, or any task with 3+ independent components. This skill changes how Claude Code approaches ALL complex work — no need to invoke manually."
---

# Parallel Orchestrator — Automatic Task Decomposition

## When This Activates (AUTO — no command needed)

This skill activates when ANY of these are true:
- Task involves 3+ independent steps
- Task touches 3+ different files or modules
- Task involves multiple services (Supabase + Railway + 2chat etc.)
- Task requires both research AND implementation
- Task involves building a system or feature with multiple components
- User says "build", "create system", "implement feature", "refactor"
- Task involves deploying, testing, AND fixing

## When This Does NOT Activate
- Single file edits
- Simple questions
- One-line fixes
- Reading/exploring code
- Conversations without tasks

---

## The Decomposition Process

### Phase 1: ANALYZE (2 seconds of thinking)

Before writing ANY code or making ANY tool call, mentally answer:

1. **What are the independent tracks?** (things that don't depend on each other)
2. **What are the dependent tracks?** (things that must happen in order)
3. **How many subagents do I need?**

### Phase 2: PLAN (declare to user)

Tell the user the plan in this format:

```
🔄 מפרק למשימות מקביליות:

Track A (subagent): [description] — [estimated scope]
Track B (subagent): [description] — [estimated scope]
Track C (subagent): [description] — [estimated scope]
Track D (sequential, after A+B): [description]

⏱️ Estimated: [time if sequential] → [time with parallel]
```

### Phase 3: EXECUTE (launch subagents)

Use the Task tool to launch ALL independent tracks simultaneously in a SINGLE message:
- Each subagent gets a clear, self-contained prompt
- Each subagent knows what files it owns (no conflicts)
- Each subagent knows what output to produce

### Phase 4: COORDINATE (after subagents return)

1. Collect results from all subagents
2. Handle any conflicts or dependencies
3. Execute sequential tracks that depend on parallel results
4. Report completion

---

## Decomposition Patterns

### Pattern: Multi-File Feature
```
User: "Add payment processing to the app"

Track A (research): Check Supabase schema, find relevant tables
Track B (research): Read PayMe API docs from config/public-apis-reference.md
Track C (research): Check existing payment code patterns
── wait ──
Track D (implement): Create payment service based on A+B+C findings
Track E (implement): Create API endpoint
Track F (implement): Add frontend UI
── wait ──
Track G (test): Run /security, /test
```

### Pattern: System Build
```
User: "Build a notification system"

Track A: Create .drawio architecture diagram
Track B: Research 2chat API + Resend API
Track C: Design Supabase tables
── wait ──
Track D: Implement backend service
Track E: Create Supabase migration + RLS
Track F: Build API endpoints
── all parallel ──
Track G: Integration test
```

### Pattern: Debug & Fix
```
User: "The app is broken, fix it"

Track A: Check Railway logs for errors
Track B: Check Supabase logs
Track C: Read recent code changes
── wait ──
Track D: Fix identified issues (parallel per file)
Track E: Test fixes
```

### Pattern: Refactor
```
User: "Refactor the authentication module"

Track A: Map all auth-related files
Track B: Identify current patterns and issues
── wait ──
Track C: Refactor file 1
Track D: Refactor file 2
Track E: Refactor file 3
── all parallel ──
Track F: Run tests, verify nothing broke
```

### Pattern: Deploy Pipeline
```
User: "Deploy everything"

Track A: TypeScript check (npx tsc -b)
── wait (must pass) ──
Track B: Deploy service 1
Track C: Deploy service 2
Track D: Deploy service 3
── all parallel ──
Track E: Verify logs for all services
```

---

## Subagent Assignment Rules

### Each subagent MUST have:
1. **Clear scope** — exactly what files/modules it owns
2. **No conflicts** — two subagents never edit the same file
3. **Self-contained prompt** — all context needed to complete the task
4. **Expected output** — what it should return when done

### Subagent types to use:
| Type | When |
|------|------|
| `Explore` | Research, file search, code reading |
| `general-purpose` | Complex multi-step tasks |
| `Bash` | Running commands, installs, builds |
| `Plan` | Architecture planning, design decisions |

### Parallel Rules:
- Independent research tasks → ALWAYS parallel
- Independent file edits (different files) → ALWAYS parallel
- Dependent tasks → sequential, but parallelize within each step
- Never launch more than 5 subagents simultaneously
- If a subagent fails → report and suggest fix, don't auto-retry

---

## Self-Check After Every Complex Task

After completing a multi-track task, run this mental checklist:

- [ ] Did I parallelize everything that could run in parallel?
- [ ] Did any subagent do work that another already did? (waste)
- [ ] Could I have decomposed differently for better speed?
- [ ] Were there file conflicts between subagents?
- [ ] Should I log a pattern in MISTAKES.md?

If something went wrong → use `/memory mistake` to log it.

---

## Examples of BAD vs GOOD

### BAD (sequential, slow):
```
1. Research file structure
2. Wait...
3. Read API docs
4. Wait...
5. Write service code
6. Wait...
7. Write tests
8. Wait...
```

### GOOD (parallel orchestration):
```
Message 1: Launch 3 subagents simultaneously
  - Subagent A: Research file structure
  - Subagent B: Read API docs
  - Subagent C: Check existing patterns

Message 2: All results in → Launch 2 subagents
  - Subagent D: Write service code
  - Subagent E: Write tests

Message 3: Done. Report results.
```

Time saved: 60%+ on complex tasks.
