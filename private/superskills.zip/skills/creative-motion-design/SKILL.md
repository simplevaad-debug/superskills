---
name: creative-motion-design
description: "Creative UI design with Framer Motion animations, cinematic backgrounds, and bold color palettes. Anti-generic, anti-AI-slop design philosophy. Auto-activates for frontend/UI work in Next.js, React, TypeScript projects. Covers: hero sections, landing pages, dashboards, cards, modals, navigation, page transitions, scroll animations, hover effects, micro-interactions, gradient backgrounds, glassmorphism, mesh gradients, image overlays, parallax, creative layouts, bento grids, asymmetric design, RTL Hebrew support."
---

# Creative Motion Design — Anti-Generic UI Intelligence

> **Philosophy:** Every pixel has purpose. Every animation tells a story. No generic templates. No AI slop.

## When to Auto-Activate

This skill activates when ANY of these are detected:
- Building UI components, pages, or layouts
- Creating landing pages, hero sections, dashboards
- Words: "design", "עיצוב", "אנימציה", "animation", "motion", "UI", "landing", "hero", "page", "component"
- Working on `.tsx`, `.jsx` files with UI elements
- User mentions: colors, backgrounds, gradients, effects, transitions
- Any frontend work in Next.js / React projects

## Stack Context (Netanel's Setup)

```
Framework:    Next.js 15 (App Router)
Language:     TypeScript (strict, no `any`)
Styling:      Tailwind CSS v4
Components:   shadcn/ui + base-ui
Animation:    Framer Motion
Font:         Heebo (Hebrew-first)
Direction:    RTL-first (dir="rtl")
Theme:        LIGHT ONLY — never dark backgrounds
Icons:        Lucide React
```

---

## GOLDEN RULES — Read Before Every UI Task

1. **NO GENERIC AI SLOP** — No bland hero sections, no cookie-cutter cards, no "Welcome to our platform"
2. **LIGHT THEME ONLY** — White/cream/warm backgrounds. Never `bg-gray-900` or dark sections
3. **RTL FIRST** — All layouts start RTL. Use `me-`, `ms-`, `start`, `end` instead of `ml-`, `mr-`, `left`, `right`
4. **HEBREW TYPOGRAPHY** — Heebo font, larger sizes for Hebrew (16px min body), generous line-height (1.7+)
5. **MOTION WITH PURPOSE** — Every animation must have a reason. No bouncing logos or spinning icons
6. **DEPTH & LAYERS** — Use shadows, overlays, blur, gradients to create visual depth
7. **ASYMMETRY > SYMMETRY** — Break grids intentionally. Offset elements. Create visual tension
8. **REAL CONTENT** — Use real Hebrew text, real images, real data. Never "Lorem ipsum"

---

## 1. FRAMER MOTION — Animation Patterns

### 1.1 Entrance Animations (Components appearing)

```tsx
// Fade up — the bread and butter
const fadeUp = {
  initial: { opacity: 0, y: 30 },
  animate: { opacity: 1, y: 0 },
  transition: { duration: 0.6, ease: [0.22, 1, 0.36, 1] }
}

// Scale in — for cards and modals
const scaleIn = {
  initial: { opacity: 0, scale: 0.9 },
  animate: { opacity: 1, scale: 1 },
  transition: { duration: 0.5, ease: [0.22, 1, 0.36, 1] }
}

// Slide from right (RTL context — content enters from right)
const slideFromRight = {
  initial: { opacity: 0, x: 60 },
  animate: { opacity: 1, x: 0 },
  transition: { duration: 0.7, ease: [0.22, 1, 0.36, 1] }
}

// Blur in — premium feel
const blurIn = {
  initial: { opacity: 0, filter: "blur(10px)" },
  animate: { opacity: 1, filter: "blur(0px)" },
  transition: { duration: 0.8 }
}
```

### 1.2 Staggered Children (Lists, grids, card groups)

```tsx
// Parent container
const staggerContainer = {
  animate: {
    transition: {
      staggerChildren: 0.08,
      delayChildren: 0.1
    }
  }
}

// Each child item
const staggerItem = {
  initial: { opacity: 0, y: 20 },
  animate: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.5, ease: [0.22, 1, 0.36, 1] }
  }
}

// Usage
<motion.div variants={staggerContainer} initial="initial" animate="animate">
  {items.map(item => (
    <motion.div key={item.id} variants={staggerItem}>
      {/* content */}
    </motion.div>
  ))}
</motion.div>
```

### 1.3 Scroll-Triggered Animations

```tsx
import { motion, useScroll, useTransform } from "framer-motion"
import { useRef } from "react"

// Parallax on scroll
function ParallaxSection() {
  const ref = useRef(null)
  const { scrollYProgress } = useScroll({
    target: ref,
    offset: ["start end", "end start"]
  })
  const y = useTransform(scrollYProgress, [0, 1], [100, -100])
  const opacity = useTransform(scrollYProgress, [0, 0.3, 0.7, 1], [0, 1, 1, 0])

  return (
    <motion.div ref={ref} style={{ y, opacity }}>
      {/* content */}
    </motion.div>
  )
}

// Reveal on scroll — use whileInView
<motion.div
  initial={{ opacity: 0, y: 40 }}
  whileInView={{ opacity: 1, y: 0 }}
  viewport={{ once: true, margin: "-100px" }}
  transition={{ duration: 0.7, ease: [0.22, 1, 0.36, 1] }}
>
```

### 1.4 Hover & Interaction Effects

```tsx
// Card hover — lift + shadow
<motion.div
  whileHover={{
    y: -8,
    boxShadow: "0 20px 40px rgba(0,0,0,0.1)",
    transition: { duration: 0.3 }
  }}
  whileTap={{ scale: 0.98 }}
>

// Button hover — scale + glow
<motion.button
  whileHover={{
    scale: 1.02,
    boxShadow: "0 0 30px rgba(99, 102, 241, 0.4)"
  }}
  whileTap={{ scale: 0.97 }}
  transition={{ type: "spring", stiffness: 400, damping: 25 }}
>

// Image hover — zoom inside container
<div className="overflow-hidden rounded-2xl">
  <motion.img
    whileHover={{ scale: 1.08 }}
    transition={{ duration: 0.6 }}
    className="w-full h-full object-cover"
  />
</div>
```

### 1.5 Page Transitions (App Router)

```tsx
// app/template.tsx — wraps every page
"use client"
import { motion } from "framer-motion"

export default function Template({ children }: { children: React.ReactNode }) {
  return (
    <motion.div
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -10 }}
      transition={{ duration: 0.4, ease: [0.22, 1, 0.36, 1] }}
    >
      {children}
    </motion.div>
  )
}
```

### 1.6 Layout Animations (Smooth reflows)

```tsx
// Auto-animate layout changes
<motion.div layout transition={{ type: "spring", stiffness: 300, damping: 30 }}>
  {/* content that changes size/position */}
</motion.div>

// AnimatePresence for mount/unmount
import { AnimatePresence } from "framer-motion"

<AnimatePresence mode="wait">
  {isOpen && (
    <motion.div
      key="modal"
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      exit={{ opacity: 0, scale: 0.95 }}
      transition={{ duration: 0.3 }}
    />
  )}
</AnimatePresence>
```

### 1.7 Custom Easing Library

```tsx
// Curated easing curves — avoid linear and basic ease
const EASE = {
  // Primary — smooth, professional
  smooth: [0.22, 1, 0.36, 1],        // cubic-bezier
  // Elastic — playful, energetic
  bounce: { type: "spring", stiffness: 300, damping: 20 },
  // Snappy — quick, responsive
  snappy: { type: "spring", stiffness: 500, damping: 30 },
  // Slow reveal — dramatic, cinematic
  cinematic: [0.16, 1, 0.3, 1],
  // Out-back — slight overshoot
  overshoot: [0.34, 1.56, 0.64, 1],
} as const
```

---

## 2. CREATIVE BACKGROUNDS — Beyond Solid Colors

### 2.1 Gradient Backgrounds

```tsx
// Warm gradient — hero sections
className="bg-gradient-to-br from-amber-50 via-white to-rose-50"

// Cool professional gradient
className="bg-gradient-to-bl from-slate-50 via-blue-50/30 to-indigo-50/50"

// Sunset warmth
className="bg-gradient-to-r from-orange-50 via-rose-50 to-purple-50"

// Multi-stop radial (Tailwind arbitrary)
className="bg-[radial-gradient(ellipse_at_top_right,_var(--tw-gradient-stops))] from-blue-100 via-transparent to-transparent"

// Animated gradient (CSS + Framer Motion)
<motion.div
  className="bg-gradient-to-r from-violet-200 via-pink-200 to-amber-200 bg-[length:200%_200%]"
  animate={{ backgroundPosition: ["0% 50%", "100% 50%", "0% 50%"] }}
  transition={{ duration: 8, repeat: Infinity, ease: "linear" }}
/>
```

### 2.2 Mesh Gradients

```tsx
// CSS mesh gradient — organic, premium feel
<div className="relative overflow-hidden">
  <div className="absolute inset-0" style={{
    background: `
      radial-gradient(at 20% 30%, rgba(99, 102, 241, 0.15) 0%, transparent 50%),
      radial-gradient(at 80% 20%, rgba(236, 72, 153, 0.12) 0%, transparent 50%),
      radial-gradient(at 40% 80%, rgba(251, 191, 36, 0.1) 0%, transparent 50%),
      radial-gradient(at 90% 70%, rgba(34, 197, 94, 0.08) 0%, transparent 50%)
    `
  }} />
  <div className="relative z-10">{/* content */}</div>
</div>
```

### 2.3 Background Images with Overlays

```tsx
// Image with gradient overlay
<div className="relative h-[500px]">
  <img
    src="/hero-bg.jpg"
    alt=""
    className="absolute inset-0 w-full h-full object-cover"
  />
  <div className="absolute inset-0 bg-gradient-to-t from-white via-white/60 to-transparent" />
  <div className="relative z-10 flex items-end h-full pb-20 px-8">
    {/* content sits on top */}
  </div>
</div>

// Blurred image background
<div className="relative overflow-hidden rounded-3xl">
  <img
    src="/feature-bg.jpg"
    alt=""
    className="absolute inset-0 w-full h-full object-cover blur-sm scale-110"
  />
  <div className="absolute inset-0 bg-white/70 backdrop-blur-sm" />
  <div className="relative z-10 p-8">{/* content */}</div>
</div>
```

### 2.4 Glassmorphism (Light Theme Safe)

```tsx
// Glass card — light theme version
<div className="backdrop-blur-xl bg-white/60 border border-white/80
  rounded-2xl shadow-[0_8px_32px_rgba(0,0,0,0.06)] p-6">
  {/* content */}
</div>

// Glass navbar
<nav className="fixed top-0 inset-x-0 z-50 backdrop-blur-lg bg-white/70
  border-b border-gray-200/50 shadow-sm">
```

### 2.5 Decorative Elements (Blobs, Shapes, Noise)

```tsx
// Floating blob — ambient background decoration
<motion.div
  className="absolute -top-40 -right-40 w-[600px] h-[600px] rounded-full
    bg-gradient-to-br from-indigo-200/40 to-purple-200/40 blur-3xl"
  animate={{
    x: [0, 30, 0],
    y: [0, -20, 0],
    scale: [1, 1.05, 1]
  }}
  transition={{ duration: 15, repeat: Infinity, ease: "easeInOut" }}
/>

// Noise texture overlay (subtle)
<div className="absolute inset-0 opacity-[0.03]"
  style={{ backgroundImage: "url('/noise.svg')", backgroundRepeat: "repeat" }}
/>

// Dot grid pattern
<div className="absolute inset-0 opacity-[0.15]"
  style={{
    backgroundImage: "radial-gradient(circle, #6366f1 1px, transparent 1px)",
    backgroundSize: "24px 24px"
  }}
/>

// Diagonal lines pattern
<div className="absolute inset-0 opacity-[0.04]"
  style={{
    backgroundImage: `repeating-linear-gradient(
      -45deg, transparent, transparent 10px, #000 10px, #000 11px
    )`
  }}
/>
```

### 2.6 Parallax Image Sections

```tsx
function ParallaxHero({ imageUrl, children }: { imageUrl: string; children: React.ReactNode }) {
  const ref = useRef(null)
  const { scrollYProgress } = useScroll({
    target: ref,
    offset: ["start start", "end start"]
  })
  const y = useTransform(scrollYProgress, [0, 1], ["0%", "30%"])

  return (
    <div ref={ref} className="relative h-[80vh] overflow-hidden">
      <motion.img
        src={imageUrl}
        alt=""
        className="absolute inset-0 w-full h-full object-cover"
        style={{ y }}
      />
      <div className="absolute inset-0 bg-gradient-to-b from-white/30 to-white" />
      <div className="relative z-10 h-full flex items-center justify-center">
        {children}
      </div>
    </div>
  )
}
```

---

## 3. COLOR PALETTES — Curated, Non-Generic

### RULE: Never use raw Tailwind defaults. Always create a curated palette.

### 3.1 Professional Palettes (Business / SaaS / Dashboard)

```tsx
// 🔷 Ocean Trust — Finance, Legal, Corporate
const oceanTrust = {
  primary:   "#1e40af",  // Deep blue
  secondary: "#3b82f6",  // Medium blue
  accent:    "#06b6d4",  // Cyan pop
  surface:   "#f8fafc",  // Cool white
  text:      "#0f172a",  // Near black
  muted:     "#64748b",  // Slate gray
  border:    "#e2e8f0",
  success:   "#10b981",
  warning:   "#f59e0b",
  error:     "#ef4444",
}

// 🟢 Fresh Growth — Health, Wellness, Eco
const freshGrowth = {
  primary:   "#059669",  // Emerald
  secondary: "#10b981",  // Light emerald
  accent:    "#fbbf24",  // Gold
  surface:   "#f0fdf4",  // Mint white
  text:      "#064e3b",  // Dark green
  muted:     "#6b7280",
  border:    "#d1fae5",
}

// 🟣 Royal Tech — AI, Innovation, Premium SaaS
const royalTech = {
  primary:   "#7c3aed",  // Violet
  secondary: "#a78bfa",  // Light violet
  accent:    "#ec4899",  // Pink pop
  surface:   "#faf5ff",  // Lavender white
  text:      "#1e1b4b",  // Deep indigo
  muted:     "#6b7280",
  border:    "#e9d5ff",
}
```

### 3.2 Warm & Inviting Palettes (Service / Real Estate / Local)

```tsx
// 🧡 Warm Sunset — Real Estate, Hospitality, Food
const warmSunset = {
  primary:   "#ea580c",  // Burnt orange
  secondary: "#f97316",  // Orange
  accent:    "#7c3aed",  // Purple contrast
  surface:   "#fffbeb",  // Warm cream
  text:      "#431407",  // Dark brown
  muted:     "#78716c",
  border:    "#fed7aa",
}

// 🏠 Earth Tone — Architecture, Interior Design, Craft
const earthTone = {
  primary:   "#92400e",  // Deep amber
  secondary: "#b45309",  // Amber
  accent:    "#0891b2",  // Teal contrast
  surface:   "#fefce8",  // Warm white
  text:      "#1c1917",  // Stone dark
  muted:     "#78716c",
  border:    "#d6d3d1",
}

// 🌸 Soft Blossom — Beauty, Wedding, Fashion
const softBlossom = {
  primary:   "#be185d",  // Deep pink
  secondary: "#ec4899",  // Pink
  accent:    "#8b5cf6",  // Purple
  surface:   "#fff1f2",  // Rose white
  text:      "#4c0519",  // Dark rose
  muted:     "#9ca3af",
  border:    "#fecdd3",
}
```

### 3.3 Bold & Energetic Palettes (Startup / Gaming / Creative)

```tsx
// ⚡ Electric Energy — Startup, Tech, Gaming
const electricEnergy = {
  primary:   "#4f46e5",  // Indigo
  secondary: "#06b6d4",  // Cyan
  accent:    "#f43f5e",  // Rose red
  surface:   "#f8fafc",  // Clean white
  text:      "#0f172a",
  muted:     "#64748b",
  gradient:  "from-indigo-500 via-purple-500 to-pink-500",
}

// 🌊 Deep Ocean — Premium, Luxury, Exclusive
const deepOcean = {
  primary:   "#0e7490",  // Dark cyan
  secondary: "#06b6d4",  // Cyan
  accent:    "#fbbf24",  // Gold
  surface:   "#ecfeff",  // Cyan tint
  text:      "#083344",  // Deep teal
  muted:     "#64748b",
  border:    "#cffafe",
}
```

### 3.4 How to Apply Palettes in Tailwind

```ts
// tailwind.config.ts — extend with custom palette
export default {
  theme: {
    extend: {
      colors: {
        brand: {
          DEFAULT: "#7c3aed",
          light:   "#a78bfa",
          dark:    "#5b21b6",
          50:      "#faf5ff",
        },
        surface: "#faf5ff",
        accent:  "#ec4899",
      },
    },
  },
}
```

---

## 4. HERO SECTION RECIPES — Not Generic

### 4.1 Split Hero (Image + Content)

```tsx
<section className="min-h-screen flex items-center" dir="rtl">
  <div className="container mx-auto px-6 grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
    {/* Text Side */}
    <motion.div
      initial={{ opacity: 0, x: 40 }}
      animate={{ opacity: 1, x: 0 }}
      transition={{ duration: 0.8, ease: [0.22, 1, 0.36, 1] }}
    >
      <span className="text-sm font-medium text-indigo-600 tracking-wide">
        קטגוריה
      </span>
      <h1 className="mt-3 text-5xl lg:text-6xl font-bold text-gray-900 leading-tight">
        כותרת ראשית
        <span className="block text-indigo-600 mt-2">עם הדגשה</span>
      </h1>
      <p className="mt-6 text-lg text-gray-600 leading-relaxed max-w-lg">
        תיאור קצר וממוקד של השירות או המוצר
      </p>
      <div className="mt-8 flex gap-4">
        <motion.button
          whileHover={{ scale: 1.02 }}
          whileTap={{ scale: 0.98 }}
          className="px-8 py-3.5 bg-indigo-600 text-white rounded-xl font-medium
            shadow-lg shadow-indigo-500/25 hover:bg-indigo-700 transition-colors"
        >
          התחל עכשיו
        </motion.button>
        <button className="px-8 py-3.5 border border-gray-300 rounded-xl
          text-gray-700 hover:bg-gray-50 transition-colors">
          למד עוד
        </button>
      </div>
    </motion.div>

    {/* Image Side */}
    <motion.div
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ duration: 1, delay: 0.2, ease: [0.22, 1, 0.36, 1] }}
      className="relative"
    >
      <div className="absolute -inset-4 bg-gradient-to-br from-indigo-200/50
        to-purple-200/50 rounded-3xl blur-2xl" />
      <img
        src="/hero-image.jpg"
        alt="תיאור"
        className="relative rounded-2xl shadow-2xl w-full"
      />
    </motion.div>
  </div>
</section>
```

### 4.2 Centered Hero with Floating Elements

```tsx
<section className="relative min-h-screen flex items-center justify-center overflow-hidden">
  {/* Background decorations */}
  <motion.div
    className="absolute top-20 right-20 w-72 h-72 bg-indigo-200/30 rounded-full blur-3xl"
    animate={{ x: [0, 30, 0], y: [0, -20, 0] }}
    transition={{ duration: 10, repeat: Infinity }}
  />
  <motion.div
    className="absolute bottom-20 left-20 w-96 h-96 bg-rose-200/30 rounded-full blur-3xl"
    animate={{ x: [0, -20, 0], y: [0, 30, 0] }}
    transition={{ duration: 12, repeat: Infinity }}
  />

  <div className="relative z-10 text-center max-w-4xl mx-auto px-6">
    <motion.div
      initial={{ opacity: 0, y: 30 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.8 }}
    >
      <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full
        bg-indigo-50 border border-indigo-200 text-indigo-700 text-sm mb-8">
        <span className="w-2 h-2 rounded-full bg-indigo-500 animate-pulse" />
        חדש! פיצ'ר מיוחד
      </div>
      <h1 className="text-5xl lg:text-7xl font-bold text-gray-900 leading-[1.1]">
        כותרת שמושכת
        <br />
        <span className="bg-gradient-to-l from-indigo-600 to-purple-600
          bg-clip-text text-transparent">
          תשומת לב
        </span>
      </h1>
      <p className="mt-6 text-xl text-gray-500 max-w-2xl mx-auto leading-relaxed">
        תיאור שמסביר בדיוק מה המוצר עושה ולמה כדאי
      </p>
    </motion.div>
  </div>
</section>
```

---

## 5. CREATIVE LAYOUT PATTERNS

### 5.1 Bento Grid

```tsx
<div className="grid grid-cols-4 gap-4 auto-rows-[180px]" dir="rtl">
  {/* Large feature card — spans 2 cols, 2 rows */}
  <motion.div
    className="col-span-2 row-span-2 rounded-3xl bg-gradient-to-br
      from-indigo-500 to-purple-600 p-8 text-white relative overflow-hidden"
    whileHover={{ scale: 1.02 }}
  >
    <h3 className="text-2xl font-bold">פיצ'ר ראשי</h3>
    <p className="mt-2 text-white/80">תיאור קצר</p>
  </motion.div>

  {/* Small cards */}
  <motion.div className="col-span-1 rounded-3xl bg-amber-50 border border-amber-200 p-6"
    whileHover={{ y: -4 }}>
    <span className="text-3xl">📊</span>
    <p className="mt-2 font-medium text-gray-900">אנליטיקות</p>
  </motion.div>

  <motion.div className="col-span-1 rounded-3xl bg-emerald-50 border border-emerald-200 p-6"
    whileHover={{ y: -4 }}>
    <span className="text-3xl">🔒</span>
    <p className="mt-2 font-medium text-gray-900">אבטחה</p>
  </motion.div>

  {/* Wide card — spans 2 cols */}
  <motion.div className="col-span-2 rounded-3xl bg-rose-50 border border-rose-200 p-6"
    whileHover={{ y: -4 }}>
    <h3 className="text-lg font-bold text-gray-900">פיצ'ר נרחב</h3>
  </motion.div>
</div>
```

### 5.2 Asymmetric Feature Section

```tsx
<section className="py-24 px-6" dir="rtl">
  <div className="max-w-7xl mx-auto grid grid-cols-12 gap-6">
    {/* Feature 1 — offset high */}
    <motion.div className="col-span-4 -mt-12"
      initial={{ opacity: 0, y: 40 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
    >
      <div className="rounded-3xl overflow-hidden shadow-xl">
        <img src="/feature-1.jpg" alt="" className="w-full h-64 object-cover" />
        <div className="p-6 bg-white">
          <h3 className="text-xl font-bold">פיצ'ר ראשון</h3>
          <p className="mt-2 text-gray-500">תיאור קצר</p>
        </div>
      </div>
    </motion.div>

    {/* Feature 2 — centered, larger */}
    <motion.div className="col-span-5 mt-8"
      initial={{ opacity: 0, y: 40 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ delay: 0.1 }}
    >
      <div className="rounded-3xl overflow-hidden shadow-xl bg-gradient-to-br
        from-indigo-500 to-purple-600 text-white p-8 h-full">
        <h3 className="text-2xl font-bold">פיצ'ר מרכזי</h3>
        <p className="mt-3 text-white/80 leading-relaxed">תיאור מורחב</p>
      </div>
    </motion.div>

    {/* Feature 3 — offset low */}
    <motion.div className="col-span-3 mt-24"
      initial={{ opacity: 0, y: 40 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      transition={{ delay: 0.2 }}
    >
      <div className="rounded-3xl bg-amber-50 border border-amber-200 p-6">
        <span className="text-4xl">⚡</span>
        <h3 className="mt-4 text-lg font-bold">מהירות</h3>
        <p className="mt-2 text-gray-500">תיאור קצר</p>
      </div>
    </motion.div>
  </div>
</section>
```

---

## 6. MICRO-INTERACTIONS

### 6.1 Button Effects

```tsx
// Magnetic button — follows cursor slightly
function MagneticButton({ children }: { children: React.ReactNode }) {
  const ref = useRef<HTMLButtonElement>(null)
  const [position, setPosition] = useState({ x: 0, y: 0 })

  const handleMouse = (e: React.MouseEvent) => {
    const { clientX, clientY } = e
    const { left, top, width, height } = ref.current!.getBoundingClientRect()
    const x = (clientX - left - width / 2) * 0.15
    const y = (clientY - top - height / 2) * 0.15
    setPosition({ x, y })
  }

  return (
    <motion.button
      ref={ref}
      onMouseMove={handleMouse}
      onMouseLeave={() => setPosition({ x: 0, y: 0 })}
      animate={position}
      transition={{ type: "spring", stiffness: 150, damping: 15 }}
      className="px-8 py-3.5 bg-indigo-600 text-white rounded-xl font-medium"
    >
      {children}
    </motion.button>
  )
}
```

### 6.2 Number Counter Animation

```tsx
function AnimatedCounter({ target, suffix = "" }: { target: number; suffix?: string }) {
  const [count, setCount] = useState(0)
  const ref = useRef(null)
  const isInView = useInView(ref, { once: true })

  useEffect(() => {
    if (!isInView) return
    const duration = 2000
    const start = performance.now()
    const step = (now: number) => {
      const progress = Math.min((now - start) / duration, 1)
      const eased = 1 - Math.pow(1 - progress, 3) // ease-out cubic
      setCount(Math.floor(eased * target))
      if (progress < 1) requestAnimationFrame(step)
    }
    requestAnimationFrame(step)
  }, [isInView, target])

  return <span ref={ref}>{count.toLocaleString()}{suffix}</span>
}
```

### 6.3 Text Reveal (Word by Word)

```tsx
function TextReveal({ text }: { text: string }) {
  const words = text.split(" ")
  return (
    <motion.p
      initial="hidden"
      whileInView="visible"
      viewport={{ once: true }}
      variants={{ visible: { transition: { staggerChildren: 0.05 } } }}
      className="text-lg text-gray-600 leading-relaxed"
    >
      {words.map((word, i) => (
        <motion.span
          key={i}
          className="inline-block me-[0.3em]"
          variants={{
            hidden: { opacity: 0, y: 10 },
            visible: { opacity: 1, y: 0, transition: { duration: 0.4 } }
          }}
        >
          {word}
        </motion.span>
      ))}
    </motion.p>
  )
}
```

---

## 7. TYPOGRAPHY PATTERNS (Hebrew)

```tsx
// Font setup — app/layout.tsx
import { Heebo } from "next/font/google"

const heebo = Heebo({
  subsets: ["hebrew", "latin"],
  weight: ["300", "400", "500", "600", "700", "800", "900"],
  variable: "--font-heebo"
})

// Type scale for Hebrew (larger than English defaults)
const typography = {
  h1: "text-4xl lg:text-6xl font-bold leading-[1.15] tracking-tight",
  h2: "text-3xl lg:text-4xl font-bold leading-[1.2]",
  h3: "text-xl lg:text-2xl font-semibold leading-[1.3]",
  body: "text-base lg:text-lg leading-[1.7] text-gray-600",
  small: "text-sm leading-[1.6] text-gray-500",
  label: "text-xs font-medium tracking-wide uppercase text-gray-400",
}

// Gradient text
<h1 className="text-5xl font-bold bg-gradient-to-l from-indigo-600 via-purple-600
  to-pink-500 bg-clip-text text-transparent">
  כותרת עם גרדיאנט
</h1>
```

---

## 8. SHADOW & DEPTH SYSTEM

```tsx
// Layered shadow system — avoid generic shadow-md
const shadows = {
  // Subtle — cards at rest
  subtle: "shadow-[0_2px_8px_rgba(0,0,0,0.04)]",
  // Medium — cards on hover, dropdowns
  medium: "shadow-[0_8px_24px_rgba(0,0,0,0.08)]",
  // Elevated — modals, popovers
  elevated: "shadow-[0_16px_48px_rgba(0,0,0,0.12)]",
  // Colored — brand shadow under CTAs
  brand: "shadow-[0_8px_24px_rgba(99,102,241,0.25)]",
  // Glow — premium effect
  glow: "shadow-[0_0_40px_rgba(99,102,241,0.15)]",
}
```

---

## 9. ACCESSIBILITY WITH MOTION

```tsx
// ALWAYS respect prefers-reduced-motion
// Wrap motion components or use Framer Motion's built-in support

// Option 1: CSS media query
@media (prefers-reduced-motion: reduce) {
  * { animation-duration: 0.01ms !important; }
}

// Option 2: Framer Motion hook
import { useReducedMotion } from "framer-motion"

function AnimatedCard({ children }: { children: React.ReactNode }) {
  const shouldReduceMotion = useReducedMotion()

  return (
    <motion.div
      initial={shouldReduceMotion ? false : { opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: shouldReduceMotion ? 0 : 0.5 }}
    >
      {children}
    </motion.div>
  )
}
```

---

## 10. ANTI-PATTERNS — What NOT to Do

| ❌ Don't | ✅ Do Instead |
|----------|--------------|
| `bg-gray-900` dark sections in light theme | Use white/cream/warm light backgrounds with colored accents |
| Generic hero with stock photo | Creative split layout, mesh gradient, or parallax with real imagery |
| Symmetric grid of 3 identical cards | Asymmetric layout, bento grid, or varied card sizes |
| `animate-bounce` on buttons | Subtle `whileHover={{ y: -2 }}` with spring physics |
| Random colors from Tailwind defaults | Curated palette from section 3 of this skill |
| Linear easing on everything | Custom `[0.22, 1, 0.36, 1]` cubic-bezier or spring physics |
| `text-sm text-gray-500` for everything | Type scale system with proper hierarchy |
| Flat cards with no depth | Layered shadows, glass effects, gradient borders |
| `ml-4` / `mr-4` in RTL context | `ms-4` / `me-4` with logical properties |
| English placeholder text | Real Hebrew content, proper Heebo typography |
| `shadow-md` default shadows | Custom shadow system from section 8 |
| Plain background with no texture | Mesh gradients, noise, dot patterns, or blurred blobs |
